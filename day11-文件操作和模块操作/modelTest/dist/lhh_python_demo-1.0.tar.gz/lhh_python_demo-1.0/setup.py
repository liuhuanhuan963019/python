#encoding=utf-8
from distutils.core import setup
#name  模块名称
#version 版本号
#description 描述
#author  作者
#py_modules 要发布的内容

setup(name="lhh_python_demo",version="1.0",description="文件的统计模块",
      author="liuhuanhuan",py_modules=['modeTest'])